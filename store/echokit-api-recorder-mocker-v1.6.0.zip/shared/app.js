// EchoKit — shared UI module.
// Used by both popup + devtools panel. Mode-switches layout, preserves scroll & cursor.

import { highlightJSON, isValidJSON } from './json-highlight.js';

const BG = (msg) => new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));

let state = {
  mode: 'popup',
  tabId: null,
  tab: { recording: false, mocking: false, sessionId: null, host: '' },
  settings: { corsOverride: false, scope: 'domain', theme: 'dark', autoOpenOnRefresh: true, blocklist: [], rewriteRules: [], transformRules: [] },
  interactions: [],
  allCount: 0,
  isPro: false,
  trial: false,
  trialDaysLeft: 0,
  waterfall: false,
  search: '',
  methodFilter: null,
  statusFilter: null,
  selectedId: null,
  detailOpen: false,
  menuOpen: false,
  listWidth: 360,
  clipboardPreview: null,
};

let root;

export async function initEchoKitUI({ mode, root: r, tabId }) {
  state.mode = mode;
  root = r;
  state.tabId = tabId ?? (await resolveTabId());

  await refresh();
  applyTheme();
  render();

  // Smart polling — only re-render when the user isn't interacting with an editable
  // field (preserves cursor), and preserve scroll positions of list + detail panes.
  setInterval(async () => {
    if (document.hidden) return;
    const ae = document.activeElement;
    const isEditing = ae && root.contains(ae) && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName);
    await refresh();
    if (!isEditing) render();
  }, 1500);

  // React instantly to pushes from the service worker (tabState, mockIndex, settings)
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === 'echokit:tabState' || msg.type === 'echokit:settings') {
      refresh().then(() => {
        const ae = document.activeElement;
        const isEditing = ae && root.contains(ae) && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName);
        if (!isEditing) render();
      });
    }
  });
}

async function resolveTabId() {
  if (typeof chrome !== 'undefined' && chrome.devtools?.inspectedWindow) {
    return chrome.devtools.inspectedWindow.tabId;
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id ?? null;
}

async function refresh() {
  const resp = await BG({ type: 'echokit:getState', tabId: state.tabId });
  if (!resp) return;
  state.tab = resp.tab || state.tab;
  state.settings = { ...state.settings, ...(resp.settings || {}) };
  state.interactions = resp.interactions || [];
  state.allCount = resp.allCount || 0;
  state.isPro = resp.isPro || false;
  state.trial = resp.trial || false;
  state.trialDaysLeft = resp.trialDaysLeft || 0;
}

function applyTheme() {
  let theme = state.settings.theme || 'dark';
  if (theme === 'auto') {
    theme = window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }
  document.documentElement.setAttribute('data-theme', theme);
}

// ---------- render ----------
function render() {
  applyTheme();
  const snapshot = snapshotUIState();

  const isPopup = state.mode === 'popup';
  const list = filteredInteractions();
  const grouped = groupByDomain(list);
  const selected = state.selectedId ? state.interactions.find(i => i.id === state.selectedId) : null;
  const conflicts = selected ? state.interactions.filter(i => i.hash === selected.hash) : [];

  const appCls = `ek-app ${state.mode} ${state.detailOpen && isPopup ? 'detail-open' : ''}`;

  root.innerHTML = `
    <div class="${appCls}" data-testid="echokit-app" style="${isPopup ? '' : `--list-width:${state.listWidth}px`}">
      ${renderHeader()}
      ${renderToolbar()}
      <div class="ek-main">
        <div class="ek-list" data-testid="api-list">
          ${state.waterfall
            ? renderWaterfall(list)
            : (list.length === 0 ? renderEmpty() : grouped.map(renderDomainGroup).join(''))}
        </div>
        ${isPopup ? '' : '<div class="ek-resizer" data-action="resize" data-testid="pane-resizer"></div>'}
        <div class="ek-detail" data-testid="api-detail">
          ${selected ? renderDetail(selected, conflicts) : renderDetailEmpty()}
        </div>
      </div>
      ${renderFooter(list.length)}
    </div>
  `;

  bindEvents();
  restoreUIState(snapshot);
  renderMenu();
  renderAllCodeEditors();
}

// Snapshot focus, selection, and scroll positions so we can restore after innerHTML wipe.
function snapshotUIState() {
  const list = root.querySelector('[data-testid="api-list"]');
  const detailBody = root.querySelector('[data-testid="api-detail"] .ek-detail-body');
  const ae = document.activeElement;
  let focus = null;
  if (ae && root.contains(ae)) {
    const testId = ae.getAttribute('data-testid');
    const action = ae.getAttribute('data-action');
    const id = ae.getAttribute('data-id');
    const key = ae.getAttribute('data-key');
    focus = {
      testId, action, id, key,
      selStart: ae.selectionStart ?? null,
      selEnd: ae.selectionEnd ?? null,
      scrollTop: ae.scrollTop ?? 0
    };
  }
  return {
    listScroll: list?.scrollTop ?? 0,
    detailScroll: detailBody?.scrollTop ?? 0,
    focus
  };
}

function restoreUIState(snap) {
  const list = root.querySelector('[data-testid="api-list"]');
  const detailBody = root.querySelector('[data-testid="api-detail"] .ek-detail-body');
  if (list) list.scrollTop = snap.listScroll;
  if (detailBody) detailBody.scrollTop = snap.detailScroll;
  if (!snap.focus) return;
  const { testId, action, id, key, selStart, selEnd, scrollTop } = snap.focus;
  let sel = '';
  if (testId) sel = `[data-testid="${testId}"]`;
  else if (action && id && key) sel = `[data-action="${action}"][data-id="${id}"][data-key="${key}"]`;
  else if (action && id) sel = `[data-action="${action}"][data-id="${id}"]`;
  else if (action) sel = `[data-action="${action}"]`;
  if (!sel) return;
  const el = root.querySelector(sel);
  if (!el) return;
  el.focus({ preventScroll: true });
  try { if (selStart != null && 'selectionStart' in el) el.setSelectionRange(selStart, selEnd ?? selStart); } catch {}
  if (scrollTop && 'scrollTop' in el) el.scrollTop = scrollTop;
}

function renderHeader() {
  const { recording, mocking } = state.tab;
  const cors = state.settings.corsOverride;
  const trialBadge = state.trial && state.trialDaysLeft > 0
    ? `<span class="ek-trial-badge" title="Pro trial: ${state.trialDaysLeft} day${state.trialDaysLeft === 1 ? '' : 's'} left">${state.trialDaysLeft}d trial</span>` : '';
  return `
    <div class="ek-header">
      <div class="ek-logo"><span class="ek-logo-mark">EK</span><span>ECHOKIT</span></div>
      ${trialBadge}
      <div class="ek-header-spacer"></div>
      ${recording
        ? `<button class="ek-btn ek-btn-record" data-action="stop-recording" data-testid="stop-recording-btn">STOP</button>`
        : `<button class="ek-btn" data-action="start-recording" data-testid="start-recording-btn">● REC</button>`}
      <label class="ek-switch ${mocking ? 'on' : ''}" data-testid="mock-master-toggle" title="Toggle mocking for this tab (Alt+Shift+M)">
        <input type="checkbox" ${mocking ? 'checked' : ''} data-action="toggle-mocking">
        <span class="ek-switch-track"></span>
        <span class="ek-switch-label">MOCK</span>
      </label>
      <label class="ek-switch ${cors ? 'on' : ''}" data-testid="cors-master-toggle" title="Inject permissive Access-Control-Allow-* on real responses (global)">
        <input type="checkbox" ${cors ? 'checked' : ''} data-action="toggle-cors-master">
        <span class="ek-switch-track"></span>
        <span class="ek-switch-label">CORS</span>
      </label>
      <button class="ek-btn ek-btn-ghost ek-btn-icon ${state.waterfall ? 'active' : ''}" data-action="toggle-waterfall"
        title="Toggle network waterfall view" data-testid="waterfall-toggle-btn">
        <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><rect x="2" y="4" width="8" height="2.5" rx="1"/><rect x="2" y="8.75" width="12" height="2.5" rx="1"/><rect x="2" y="13.5" width="6" height="2.5" rx="1"/></svg>
      </button>
      <div class="ek-menu">
        <button class="ek-btn ek-btn-ghost ek-btn-icon" data-action="toggle-menu" title="More actions" data-testid="menu-btn" aria-label="menu">
          <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><circle cx="4" cy="10" r="1.6"/><circle cx="10" cy="10" r="1.6"/><circle cx="16" cy="10" r="1.6"/></svg>
        </button>
      </div>
    </div>
  `;
}

function renderMenu() {
  // Remove any existing menu panel
  document.querySelectorAll('.ek-menu-panel').forEach(n => n.remove());
  if (!state.menuOpen) return;
  const anchor = root.querySelector('[data-testid="menu-btn"]');
  if (!anchor) return;
  const panel = document.createElement('div');
  panel.className = 'ek-menu-panel';
  panel.setAttribute('data-testid', 'menu-panel');
  const pasteHint = state.clipboardPreview
    ? `<span class="ek-subtle">${state.clipboardPreview.count} keys · ${escapeHtml(state.clipboardPreview.origin || '')}</span>`
    : `<span class="ek-subtle">nothing in clipboard</span>`;
  const proTag = `<span class="ek-pro-tag">PRO</span>`;
  panel.innerHTML = `
    <button class="ek-menu-item" data-menu="clear" data-testid="menu-clear">Clear recordings <span class="ek-subtle">${state.interactions.length}</span></button>
    <button class="ek-menu-item" data-menu="export" data-testid="menu-export">Export JSON</button>
    <button class="ek-menu-item" data-menu="import" data-testid="menu-import">Import JSON</button>
    <button class="ek-menu-item" data-menu="import-har" data-testid="menu-import-har">Import HAR ${state.isPro ? '' : proTag}</button>
    <button class="ek-menu-item" data-menu="export-har" data-testid="menu-export-har">Export HAR <span class="ek-subtle">DevTools-compatible</span>${state.isPro ? '' : proTag}</button>
    <button class="ek-menu-item" data-menu="export-postman" data-testid="menu-export-postman">Export Postman Collection ${state.isPro ? '' : proTag}</button>
    <button class="ek-menu-item" data-menu="import-openapi" data-testid="menu-import-openapi">Import OpenAPI / Swagger JSON</button>
    <div class="ek-menu-sep"></div>
    <button class="ek-menu-item" data-menu="ls-copy" data-testid="menu-ls-copy">Copy localStorage ${state.isPro ? '<span class="ek-subtle">active tab</span>' : proTag}</button>
    <button class="ek-menu-item" data-menu="ls-paste" data-testid="menu-ls-paste" ${state.clipboardPreview && state.clipboardPreview.kind === 'localStorage' ? 'style="border:1px solid rgba(251,191,36,0.4);background:rgba(251,191,36,0.06)"' : ''}>Paste localStorage ${state.isPro ? pasteHint : proTag}</button>
    <button class="ek-menu-item" data-menu="ck-copy" data-testid="menu-ck-copy">Copy cookies ${state.isPro ? '<span class="ek-subtle">active tab</span>' : proTag}</button>
    <button class="ek-menu-item" data-menu="ck-paste" data-testid="menu-ck-paste" ${state.clipboardPreview && state.clipboardPreview.kind === 'cookies' ? 'style="border:1px solid rgba(251,191,36,0.4);background:rgba(251,191,36,0.06)"' : ''}>Paste cookies ${state.isPro ? '' : proTag}</button>
    <div class="ek-menu-sep"></div>
    <button class="ek-menu-item" data-menu="gist-upload" data-testid="menu-gist-upload">Upload to GitHub Gist ${state.isPro ? '<span class="ek-subtle">share w/ team</span>' : proTag}</button>
    <button class="ek-menu-item" data-menu="gist-import" data-testid="menu-gist-import">Import from Gist URL ${state.isPro ? '' : proTag}</button>
    <div class="ek-menu-sep"></div>
    <button class="ek-menu-item" data-menu="settings" data-testid="menu-settings">Settings <span class="ek-subtle">theme · scope · cors · blocklist</span></button>
    <button class="ek-menu-item" data-menu="shortcuts" data-testid="menu-shortcuts">Keyboard shortcuts</button>
  `;
  document.body.appendChild(panel);
  const rect = anchor.getBoundingClientRect();
  panel.style.position = 'fixed';
  panel.style.top = `${rect.bottom + 6}px`;
  panel.style.right = `${Math.max(8, window.innerWidth - rect.right)}px`;

  panel.querySelectorAll('[data-menu]').forEach(el => el.addEventListener('click', () => {
    const which = el.getAttribute('data-menu');
    state.menuOpen = false;
    if (which === 'clear') onClearSession();
    else if (which === 'export') onExport();
    else if (which === 'export-har') onExportHar();
    else if (which === 'export-postman') onExportPostman();
    else if (which === 'import') showImportDialog();
    else if (which === 'import-har') onImportHar();
    else if (which === 'import-openapi') onImportOpenAPI();
    else if (which === 'ls-copy') onCopyLocalStorage();
    else if (which === 'ls-paste') onPasteLocalStorage();
    else if (which === 'ck-copy') onCopyCookies();
    else if (which === 'ck-paste') onPasteCookies();
    else if (which === 'gist-upload') { if (!state.isPro) { showProGate('GitHub Gist Sync'); } else { showGistUploadDialog(); } }
    else if (which === 'gist-import') { if (!state.isPro) { showProGate('GitHub Gist Sync'); } else { showGistImportDialog(); } }
    else if (which === 'settings') showSettingsDialog();
    else if (which === 'shortcuts') showShortcutsDialog();
    document.querySelectorAll('.ek-menu-panel').forEach(n => n.remove());
  }));

  setTimeout(() => {
    const close = (ev) => {
      if (panel.contains(ev.target)) return;
      if (ev.target.closest('[data-testid="menu-btn"]')) return;
      state.menuOpen = false;
      panel.remove();
      document.removeEventListener('click', close, true);
    };
    document.addEventListener('click', close, true);
  }, 0);
}

async function tryReadClipboardPreview() {
  try {
    const text = await navigator.clipboard.readText();
    const j = JSON.parse(text);
    if (j && j.__echokit === 'localStorage' && j.keys && typeof j.keys === 'object') {
      state.clipboardPreview = { kind: 'localStorage', count: Object.keys(j.keys).length, origin: j.origin || '', payload: j };
    } else if (j && j.__echokit === 'cookies' && Array.isArray(j.cookies)) {
      state.clipboardPreview = { kind: 'cookies', count: j.cookies.length, origin: j.origin || '', payload: j };
    } else {
      state.clipboardPreview = null;
    }
  } catch { state.clipboardPreview = null; }
}

async function onExportHar() {
  if (!state.isPro) { showProGate('HAR Export'); return; }
  const res = await BG({ type: 'echokit:export:har' });
  if (!res?.ok) { alert('HAR export failed'); return; }
  const blob = new Blob([JSON.stringify(res.data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = `echokit-${Date.now()}.har`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
  toast('HAR file downloaded');
}

async function onExportPostman() {
  if (!state.isPro) { showProGate('Postman Export'); return; }
  const res = await BG({ type: 'echokit:export:postman' });
  if (!res?.ok) { alert('Postman export failed'); return; }
  const blob = new Blob([JSON.stringify(res.data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = `echokit-collection-${Date.now()}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
  toast('Postman collection downloaded');
}

function onImportHar() {
  if (!state.isPro) { showProGate('HAR Import'); return; }
  const input = document.createElement('input');
  input.type = 'file'; input.accept = '.har,application/json';
  input.onchange = async () => {
    const file = input.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!data?.log?.entries) { alert('Invalid HAR file — missing log.entries'); return; }
      const strategy = confirm('Override existing recordings?\nOK = Replace all\nCancel = Merge') ? 'override' : 'merge';
      const res = await BG({ type: 'echokit:import:har', data, strategy });
      if (res?.ok) { toast(`Imported ${res.imported} entries from HAR`); await refresh(); render(); }
      else alert('HAR import failed: ' + (res?.error || 'unknown'));
    } catch (e) { alert('Failed to parse HAR: ' + e.message); }
  };
  input.click();
}

function onImportOpenAPI() {
  const input = document.createElement('input');
  input.type = 'file'; input.accept = '.json,application/json';
  input.onchange = async () => {
    const file = input.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const baseUrl = prompt('Override base URL? (leave blank to use spec servers[])', '') || '';
      const res = await BG({ type: 'echokit:import:openapi', data, baseUrl });
      if (res?.ok) { toast(`Imported ${res.imported} mock${res.imported === 1 ? '' : 's'} from OpenAPI spec`); await refresh(); render(); }
      else alert('OpenAPI import failed: ' + (res?.error || 'unknown'));
    } catch (e) { alert('Failed to parse spec: ' + e.message); }
  };
  input.click();
}

function showProGate(feature) {
  const overlay = document.createElement('div');
  overlay.className = 'ek-modal-overlay';
  overlay.innerHTML = `
    <div class="ek-modal ek-pro-gate" data-testid="pro-gate-modal">
      <div class="ek-pro-badge">PRO</div>
      <div class="ek-modal-title">${escapeHtml(feature)}</div>
      <div class="ek-subtle" style="margin:8px 0 16px">Upgrade to <strong>EchoKit Pro</strong> to unlock this feature plus unlimited recordings, WebSocket mocking, advanced matching, HAR/Postman export, GitHub Gist sync, and more.</div>
      <div class="ek-modal-actions">
        <button class="ek-btn ek-btn-ghost" data-a="later">Maybe later</button>
        <button class="ek-btn ek-btn-primary" data-a="upgrade" data-testid="pro-gate-upgrade-btn">Upgrade to Pro →</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
  overlay.querySelector('[data-a="later"]').addEventListener('click', () => overlay.remove());
  overlay.querySelector('[data-a="upgrade"]').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://echokit.dev/pricing' }).catch(() => window.open('https://echokit.dev/pricing', '_blank'));
    overlay.remove();
  });
}

async function onCopyCookies() {
  if (!state.isPro) { showProGate('Cookies Copy'); return; }
  if (state.tabId == null) { alert('No active tab'); return; }
  const r = await BG({ type: 'echokit:cookies:read', tabId: state.tabId });
  if (!r?.ok) { alert('Failed to read cookies: ' + (r?.error || 'unknown')); return; }
  const payload = { __echokit: 'cookies', version: 1, origin: r.origin, copiedAt: new Date().toISOString(), cookies: r.cookies };
  try {
    await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
    await tryReadClipboardPreview(); render();
    toast(`Copied ${r.count} cookies from ${r.origin}`);
  } catch (e) { alert('Clipboard write failed: ' + e.message); }
}

async function onPasteCookies() {
  if (!state.isPro) { showProGate('Cookies Paste'); return; }
  await tryReadClipboardPreview();
  if (!state.clipboardPreview || state.clipboardPreview.kind !== 'cookies') {
    alert('Clipboard has no EchoKit cookies payload.\nCopy from another tab first via Menu → Copy cookies.');
    return;
  }
  const { count, origin, payload } = state.clipboardPreview;
  if (!confirm(`Write ${count} cookies from ${origin} into ${state.tab.host || 'active tab'}?`)) return;
  const r = await BG({ type: 'echokit:cookies:write', tabId: state.tabId, cookies: payload.cookies });
  if (r?.ok) toast(`Wrote ${r.written} cookies. Reload the tab.`);
  else alert('Paste failed: ' + (r?.error || 'unknown'));
}

async function onCopyLocalStorage() {
  if (!state.isPro) { showProGate('LocalStorage Copy'); return; }
  if (state.tabId == null) { alert('No active tab'); return; }
  const r = await BG({ type: 'echokit:localStorage:read', tabId: state.tabId });
  if (!r?.ok) { alert('Failed to read localStorage: ' + (r?.error || 'unknown — tab may not be http(s)')); return; }
  const payload = { __echokit: 'localStorage', version: 1, origin: r.origin, href: r.href, copiedAt: new Date().toISOString(), keys: r.keys };
  try {
    await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
    await tryReadClipboardPreview();
    render();
    toast(`Copied ${r.count} localStorage keys from ${r.origin}`);
  } catch (e) { alert('Clipboard write failed: ' + e.message); }
}

async function onPasteLocalStorage() {
  if (!state.isPro) { showProGate('LocalStorage Paste'); return; }
  await tryReadClipboardPreview();
  if (!state.clipboardPreview) { alert('Clipboard has no EchoKit localStorage payload.\nCopy from another tab first via Menu → Copy localStorage.'); return; }
  const { count, origin, payload } = state.clipboardPreview;
  showPasteDialog(count, origin, payload);
}

function showPasteDialog(count, origin, payload) {
  const overlay = document.createElement('div');
  overlay.className = 'ek-modal-overlay';
  const preview = Object.entries(payload.keys || {}).slice(0, 10).map(([k, v]) => `<div class="ek-kv-row"><span class="ek-tag" style="font-family:var(--font-mono)">${escapeHtml(k)}</span><span class="ek-subtle" style="font-family:var(--font-mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(String(v).slice(0, 80))}</span><span></span></div>`).join('');
  const more = Object.keys(payload.keys || {}).length > 10 ? `<div class="ek-subtle">…and ${Object.keys(payload.keys).length - 10} more</div>` : '';
  overlay.innerHTML = `
    <div class="ek-modal" data-testid="paste-modal">
      <div class="ek-modal-title">Paste localStorage</div>
      <div class="ek-subtle">${count} keys · from <span class="ek-tag">${escapeHtml(origin)}</span> → into <span class="ek-tag">${escapeHtml(state.tab.host || 'active tab')}</span></div>
      ${origin && state.tab.host && !origin.includes(state.tab.host) ? `<div class="ek-subtle" style="color:var(--amber)">⚠ Origins differ — paste will write into the current tab's origin, which may overwrite unrelated data.</div>` : ''}
      <div style="max-height:220px;overflow:auto">${preview}${more}</div>
      <label class="ek-row-inline" style="gap:6px;margin-top:4px">
        <input type="checkbox" data-a="clear-first" data-testid="paste-clear-first"/> <span>Clear existing localStorage before pasting</span>
      </label>
      <div class="ek-modal-actions">
        <button class="ek-btn ek-btn-ghost" data-a="cancel">Cancel</button>
        <button class="ek-btn ek-btn-primary" data-a="confirm" data-testid="paste-confirm">Apply</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  overlay.querySelector('[data-a="cancel"]').addEventListener('click', () => overlay.remove());
  overlay.querySelector('[data-a="confirm"]').addEventListener('click', async () => {
    const clearFirst = overlay.querySelector('[data-a="clear-first"]').checked;
    const r = await BG({ type: 'echokit:localStorage:write', tabId: state.tabId, keys: payload.keys, clearFirst });
    overlay.remove();
    if (r?.ok) toast(`Wrote ${r.written} keys to ${r.origin}. Reload the tab to apply.`);
    else alert('Paste failed: ' + (r?.error || 'unknown'));
  });
}

function toast(text) {
  const t = document.createElement('div');
  t.textContent = text;
  t.style.cssText = 'position:fixed;bottom:16px;left:50%;transform:translateX(-50%);background:var(--surface);color:var(--text);border:1px solid var(--border-strong);border-radius:8px;padding:10px 16px;font-size:12px;z-index:200;box-shadow:0 6px 24px rgba(0,0,0,0.4)';
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

// ---------- Gist sync ----------
function showGistUploadDialog() {
  const lastToken = localStorage.getItem('ek_gist_token') || '';
  const overlay = document.createElement('div');
  overlay.className = 'ek-modal-overlay';
  overlay.innerHTML = `
    <div class="ek-modal" data-testid="gist-upload-modal">
      <div class="ek-modal-title">Share mocks via GitHub Gist</div>
      <div class="ek-subtle">Uploads your full mock set as a JSON file to a new gist. Teammates can import from the URL.</div>
      <div class="ek-field">
        <div class="ek-label">GitHub Personal Access Token <span class="ek-subtle">(gist scope)</span></div>
        <input class="ek-input" type="password" value="${lastToken}" placeholder="ghp_..." data-a="token" data-testid="gist-token" autocomplete="off"/>
        <div class="ek-subtle" style="margin-top:4px">Create at <span class="ek-tag">github.com/settings/tokens</span> with just <span class="ek-tag">gist</span> scope. Stored locally in this extension only.</div>
      </div>
      <div class="ek-field">
        <div class="ek-label">Description</div>
        <input class="ek-input" type="text" value="EchoKit mock set — ${state.tab.host || ''}" data-a="desc" data-testid="gist-desc"/>
      </div>
      <label class="ek-row-inline" style="gap:6px"><input type="checkbox" data-a="public"/> <span>Public gist</span></label>
      <div class="ek-modal-actions">
        <button class="ek-btn ek-btn-ghost" data-a="cancel">Cancel</button>
        <button class="ek-btn ek-btn-primary" data-a="upload" data-testid="gist-upload-confirm">Upload</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  overlay.querySelector('[data-a="cancel"]').addEventListener('click', () => overlay.remove());
  overlay.querySelector('[data-a="upload"]').addEventListener('click', async (e) => {
    const token = overlay.querySelector('[data-a="token"]').value.trim();
    const desc = overlay.querySelector('[data-a="desc"]').value;
    const pub = overlay.querySelector('[data-a="public"]').checked;
    if (!token) return alert('Paste a GitHub token with gist scope first.');
    localStorage.setItem('ek_gist_token', token);
    e.target.disabled = true; e.target.textContent = 'Uploading…';
    const r = await BG({ type: 'echokit:gist:upload', token, description: desc, public: pub });
    overlay.remove();
    if (r?.ok) {
      try { await navigator.clipboard.writeText(r.url); } catch {}
      toast(`Uploaded — gist URL copied: ${r.url}`);
    } else alert('Gist upload failed: ' + (r?.error || 'unknown'));
  });
}

function showGistImportDialog() {
  const overlay = document.createElement('div');
  overlay.className = 'ek-modal-overlay';
  overlay.innerHTML = `
    <div class="ek-modal" data-testid="gist-import-modal">
      <div class="ek-modal-title">Import mocks from Gist</div>
      <div class="ek-subtle">Paste a public gist URL or a raw file URL. No token needed for public gists.</div>
      <input class="ek-input" type="text" placeholder="https://gist.github.com/user/abc123..." data-a="url" data-testid="gist-url"/>
      <label class="ek-row-inline" style="gap:6px"><input type="radio" name="ek-gst" value="merge" checked/> <span>Merge (replace by id)</span></label>
      <label class="ek-row-inline" style="gap:6px"><input type="radio" name="ek-gst" value="override"/> <span>Override (wipe existing)</span></label>
      <div class="ek-modal-actions">
        <button class="ek-btn ek-btn-ghost" data-a="cancel">Cancel</button>
        <button class="ek-btn ek-btn-primary" data-a="import" data-testid="gist-import-confirm">Import</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  overlay.querySelector('[data-a="cancel"]').addEventListener('click', () => overlay.remove());
  overlay.querySelector('[data-a="import"]').addEventListener('click', async (e) => {
    const url = overlay.querySelector('[data-a="url"]').value.trim();
    const strategy = overlay.querySelector('input[name="ek-gst"]:checked').value;
    if (!url) return alert('Paste a gist URL first.');
    e.target.disabled = true; e.target.textContent = 'Importing…';
    const r = await BG({ type: 'echokit:gist:import', url, strategy });
    overlay.remove();
    if (r?.ok) { await refresh(); render(); toast(`Imported ${r.imported} mocks from gist`); }
    else alert('Gist import failed: ' + (r?.error || 'unknown'));
  });
}

function renderToolbar() {
  const methods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];
  return `
    <div class="ek-toolbar">
      <input class="ek-search" type="text" placeholder="search url…" value="${escapeHtml(state.search)}" data-action="search" data-testid="search-input" autocomplete="off" spellcheck="false"/>
      <div class="ek-method-chips">
        ${methods.map(m => `<button class="ek-chip ${state.methodFilter === m ? 'active' : ''}" data-action="filter-method" data-method="${m}" data-testid="filter-${m.toLowerCase()}">${m}</button>`).join('')}
      </div>
      <select class="ek-select" data-action="filter-status" style="max-width: 110px" data-testid="filter-status">
        <option value="">status: all</option>
        <option value="2" ${state.statusFilter === '2' ? 'selected' : ''}>2xx</option>
        <option value="3" ${state.statusFilter === '3' ? 'selected' : ''}>3xx</option>
        <option value="4" ${state.statusFilter === '4' ? 'selected' : ''}>4xx</option>
        <option value="5" ${state.statusFilter === '5' ? 'selected' : ''}>5xx</option>
        <option value="0" ${state.statusFilter === '0' ? 'selected' : ''}>failed</option>
      </select>
    </div>
  `;
}

function renderWaterfall(interactions) {
  if (!interactions.length) return renderEmpty();
  // Sort by start time
  const rows = interactions.map(i => ({
    ...i,
    startAt: i.timestamp - (i.durationMs || 0)
  })).sort((a, b) => a.startAt - b.startAt);
  const minT = rows[0].startAt;
  const maxT = Math.max(...rows.map(r => r.startAt + (r.durationMs || 1)));
  const totalSpan = Math.max(maxT - minT, 1);
  const METHOD_COLORS = { GET: '#60a5fa', POST: '#34d399', PUT: '#f59e0b', PATCH: '#a78bfa', DELETE: '#ef4444', WS: '#f97316', SSE: '#f97316' };
  return `
    <div class="ek-waterfall" data-testid="waterfall-view">
      <div class="ek-waterfall-header">
        <span class="ek-waterfall-col-method">Method</span>
        <span class="ek-waterfall-col-path">Path</span>
        <span class="ek-waterfall-col-status">Status</span>
        <span class="ek-waterfall-col-bar">Timeline (${totalSpan < 1000 ? totalSpan + 'ms' : (totalSpan / 1000).toFixed(2) + 's'})</span>
      </div>
      ${rows.map(r => {
        const relStart = ((r.startAt - minT) / totalSpan) * 100;
        const relWidth = Math.max((r.durationMs || 1) / totalSpan * 100, 0.8);
        const color = METHOD_COLORS[r.method] || '#8b8fa8';
        const st = r.overrideStatus ?? r.responseStatus;
        const stColor = st >= 500 ? '#ef4444' : st >= 400 ? '#f97316' : '#34d399';
        const path = (() => { try { return new URL(r.url).pathname; } catch { return r.url; } })();
        return `
          <div class="ek-waterfall-row ${r.id === state.selectedId ? 'selected' : ''}"
               data-action="select" data-id="${r.id}" data-testid="waterfall-row"
               title="${escapeHtml(r.url)}\n${r.durationMs || 0}ms">
            <span class="ek-waterfall-col-method">
              <span class="ek-method-badge" style="background:${color}22;color:${color};border-color:${color}44">${r.method}</span>
            </span>
            <span class="ek-waterfall-col-path ek-mono">${escapeHtml(path.slice(0, 40))}</span>
            <span class="ek-waterfall-col-status" style="color:${stColor}">${st ?? '—'}</span>
            <span class="ek-waterfall-col-bar">
              <span class="ek-waterfall-bar" style="left:${relStart.toFixed(1)}%;width:${relWidth.toFixed(1)}%;background:${color}"></span>
              <span class="ek-waterfall-bar-label">${r.durationMs ? r.durationMs + 'ms' : ''}</span>
            </span>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function renderEmpty() {
  return `
    <div class="ek-empty" data-testid="empty-state">
      <div class="ek-empty-mark">[ EK ]</div>
      <div class="ek-empty-title">${state.tab.recording ? 'Listening for API calls…' : 'No requests recorded yet'}</div>
      <div class="ek-empty-hint">${state.tab.recording
        ? `Trigger some fetch or XHR calls on <span class="ek-tag">${escapeHtml(state.tab.host || 'this page')}</span> — they'll appear here instantly.`
        : 'Hit the ● REC button above (or press <span class="ek-kbd">Alt+Shift+R</span>) to start capturing fetch/XHR on this tab.'}</div>
      ${state.allCount > 0 ? `<div class="ek-subtle">${state.allCount} recordings exist in other scopes — change <em>Scope</em> in Settings to see them.</div>` : ''}
    </div>
  `;
}

function renderDomainGroup(g) {
  return `
    <div class="ek-domain" data-testid="domain-group">${escapeHtml(g.domain)} <span class="ek-domain-count">· ${g.items.length}</span></div>
    ${g.items.map(renderRow).join('')}
  `;
}

function renderRow(i) {
  const versionCount = state.interactions.filter(x => x.hash === i.hash).length;
  const conflict = versionCount > 1;
  const active = state.selectedId === i.id ? 'active' : '';
  const method = (i.method || 'GET').toUpperCase();
  const urlPretty = prettyUrl(i.url);
  const statusClass = 's' + String(Math.floor((i.responseStatus || 0) / 100));
  const mode = i.matchMode || 'strict';
  return `
    <div class="ek-row ${active}" data-id="${i.id}" data-action="select" data-testid="api-row">
      <span class="ek-method ${method}">${method}</span>
      <div class="ek-url" title="${escapeHtml(i.url)}"><span class="ek-url-path">${escapeHtml(urlPretty.path)}</span><span class="ek-url-query">${escapeHtml(urlPretty.query)}</span></div>
      ${mode !== 'strict' ? `<span class="ek-mode-badge" title="match mode: ${mode}">${modeBadge(mode)}</span>` : ''}
      ${conflict ? `<span class="ek-conflict-badge" title="${versionCount} versions">×${versionCount}</span>` : ''}
      <span class="ek-status ${statusClass}">${i.responseStatus || 'ERR'}</span>
      <button class="ek-mock-toggle ${i.mockEnabled ? 'on' : ''}" data-action="toggle-mock" data-id="${i.id}" title="${i.mockEnabled ? 'Mock ON' : 'Mock OFF'}" data-testid="mock-toggle"></button>
      <button class="ek-block-btn ${i.blocked ? 'on' : ''}" data-action="toggle-block" data-id="${i.id}" title="${i.blocked ? 'BLOCKED — click to unblock' : 'Block this API at network level'}" data-testid="block-btn">⊘</button>
    </div>
  `;
}
function modeBadge(mode) {
  return { 'ignore-query': 'NOQ', 'ignore-body': 'NOB', 'path-wildcard': 'PATH' }[mode] || mode;
}

function renderDetailEmpty() {
  if (state.mode === 'popup' && !state.detailOpen) {
    return `<div class="ek-empty"><div class="ek-empty-hint ek-subtle">Tap a request to edit its mock.</div></div>`;
  }
  return `<div class="ek-empty"><div class="ek-empty-mark">·</div><div class="ek-empty-title">Select a request</div><div class="ek-empty-hint">Click any API call on the left to inspect + edit its mocked response.</div></div>`;
}

function renderDetail(i, conflicts) {
  const activeId = conflicts.length > 1 ? (i.activeVersionId || conflicts.sort((a,b)=>b.timestamp-a.timestamp)[0].id) : i.id;
  const overrideBody = i.overrideBody ?? i.responseBody ?? '';
  const overrideStatus = i.overrideStatus ?? i.responseStatus ?? 200;
  const overrideHeaders = i.overrideHeaders || i.responseHeaders || {};
  const matchMode = i.matchMode || 'strict';

  return `
    <div class="ek-detail-head">
      <span class="ek-method ${(i.method||'GET').toUpperCase()}">${(i.method||'GET').toUpperCase()}</span>
      <div class="ek-detail-title">${escapeHtml(i.url)}</div>
      <button class="ek-close" data-action="close-detail" data-testid="close-detail" aria-label="close">✕</button>
    </div>
    <div class="ek-detail-body">
      ${conflicts.length > 1 ? `
      <div class="ek-section" data-testid="conflict-picker">
        <div class="ek-section-head">
          <span>Multiple Versions</span>
          <span class="ek-conflict-badge">${conflicts.length}</span>
          <div class="ek-row-inline-end ek-version-picker">
            <select class="ek-select" data-action="set-active-version" data-testid="version-select">
              ${conflicts.sort((a,b)=>b.timestamp-a.timestamp).map(c =>
                `<option value="${c.id}" ${c.id === activeId ? 'selected' : ''}>${new Date(c.timestamp).toLocaleString()} — ${c.responseStatus}</option>`
              ).join('')}
            </select>
          </div>
        </div>
        <div class="ek-section-body ek-subtle">Latest version is used by default. Pick another to force it active when mocking.</div>
      </div>` : ''}

      <div class="ek-section">
        <div class="ek-section-head">
          <span>Mock Behaviour</span>
          <div class="ek-row-inline-end">
            <label class="ek-switch ${i.mockEnabled ? 'on' : ''}">
              <input type="checkbox" ${i.mockEnabled ? 'checked' : ''} data-action="toggle-mock" data-id="${i.id}"/>
              <span class="ek-switch-track"></span>
              <span class="ek-switch-label">${i.mockEnabled ? 'ON' : 'OFF'}</span>
            </label>
          </div>
        </div>
        <div class="ek-section-body">
          <div class="ek-sim-grid">
            <div class="ek-field">
              <div class="ek-label">Match Mode</div>
              <select class="ek-select" data-action="update-match-mode" data-id="${i.id}" data-testid="match-mode-select">
                <option value="strict" ${matchMode==='strict'?'selected':''}>strict — method + url + body</option>
                <option value="ignore-query" ${matchMode==='ignore-query'?'selected':''}>ignore query params</option>
                <option value="ignore-body" ${matchMode==='ignore-body'?'selected':''}>ignore body</option>
                <option value="path-wildcard" ${matchMode==='path-wildcard'?'selected':''}>path only (wildcard)</option>
                <option value="graphql" ${matchMode==='graphql'?'selected':''}>graphql — op + query + vars</option>
                <option value="graphql-op" ${matchMode==='graphql-op'?'selected':''}>graphql — op + query (any vars)</option>
              </select>
            </div>
            <div class="ek-field">
              <div class="ek-label">Latency (ms)</div>
              <div class="ek-row-inline">
                <input class="ek-slider" type="range" min="0" max="10000" step="50" value="${i.mockLatency || 0}" data-action="update-latency" data-id="${i.id}" data-testid="latency-slider"/>
                <input class="ek-input" type="number" min="0" style="max-width: 88px" value="${i.mockLatency || 0}" data-action="update-latency-input" data-id="${i.id}"/>
              </div>
            </div>
          </div>
          <div class="ek-field">
            <div class="ek-label">Error Simulation</div>
            <select class="ek-select" data-action="update-error-mode" data-id="${i.id}" data-testid="error-mode-select">
              <option value="none" ${i.mockErrorMode === 'none' || !i.mockErrorMode ? 'selected' : ''}>none</option>
              <option value="4xx" ${i.mockErrorMode === '4xx' ? 'selected' : ''}>force 4xx (400)</option>
              <option value="5xx" ${i.mockErrorMode === '5xx' ? 'selected' : ''}>force 5xx (500)</option>
              <option value="network" ${i.mockErrorMode === 'network' ? 'selected' : ''}>block / network failure</option>
              <option value="timeout" ${i.mockErrorMode === 'timeout' ? 'selected' : ''}>timeout (hang)</option>
            </select>
          </div>
        </div>
      </div>

      <div class="ek-section">
        <div class="ek-section-head"><span>Response</span></div>
        <div class="ek-section-body">
          <div class="ek-field">
            <div class="ek-label">Status Code</div>
            <input class="ek-input" type="number" value="${overrideStatus}" data-action="update-status" data-id="${i.id}" data-testid="status-input"/>
          </div>
          <div class="ek-field">
            <div class="ek-label">Body (raw JSON or text)</div>
            <div class="ek-code-editor" data-testid="body-editor-wrap">
              <pre class="ek-code-mirror" data-mirror-for="body-${i.id}" aria-hidden="true"></pre>
              <textarea class="ek-code-input" spellcheck="false" data-action="update-body" data-id="${i.id}" data-testid="body-editor" data-ce-id="body-${i.id}">${escapeHtml(typeof overrideBody === 'string' ? overrideBody : JSON.stringify(overrideBody))}</textarea>
            </div>
            <div class="ek-row-inline" style="margin-top:6px;gap:6px">
              <button class="ek-btn ek-btn-ghost" data-action="format-json" data-id="${i.id}" data-testid="format-json-btn">Format JSON</button>
              <button class="ek-btn ek-btn-ghost" data-action="reset-body" data-id="${i.id}">Reset</button>
              <span class="ek-subtle ek-row-inline-end" data-testid="body-save-status">saved</span>
            </div>
          </div>
          <div class="ek-field">
            <div class="ek-label">Headers</div>
            <div data-testid="headers-list">
              ${Object.entries(overrideHeaders).map(([k, v], idx) => `
                <div class="ek-kv-row">
                  <input class="ek-input" value="${escapeHtml(k)}" data-action="header-key" data-id="${i.id}" data-idx="${idx}" data-orig="${escapeHtml(k)}"/>
                  <input class="ek-input" value="${escapeHtml(String(v))}" data-action="header-val" data-id="${i.id}" data-key="${escapeHtml(k)}"/>
                  <button class="ek-kv-remove" data-action="header-remove" data-id="${i.id}" data-key="${escapeHtml(k)}" aria-label="remove">×</button>
                </div>
              `).join('')}
            </div>
            <button class="ek-btn ek-btn-ghost" data-action="header-add" data-id="${i.id}" style="margin-top: 4px">＋ Add header</button>
          </div>
        </div>
      </div>

      <div class="ek-section">
        <div class="ek-section-head"><span>Request</span></div>
        <div class="ek-section-body">
          <div class="ek-field">
            <div class="ek-label">Body</div>
            <div class="ek-code-editor">
              <pre class="ek-code-mirror" data-mirror-for="req-${i.id}" aria-hidden="true"></pre>
              <textarea class="ek-code-input" readonly spellcheck="false" data-ce-id="req-${i.id}">${escapeHtml(typeof i.requestBody === 'string' ? i.requestBody : (i.requestBody == null ? '' : JSON.stringify(i.requestBody)))}</textarea>
            </div>
          </div>
          <div class="ek-field">
            <div class="ek-label">Headers</div>
            <pre class="ek-textarea" style="min-height: 60px">${escapeHtml(Object.entries(i.requestHeaders || {}).map(([k, v]) => `${k}: ${v}`).join('\n'))}</pre>
          </div>
        </div>
      </div>

      <div class="ek-row-inline">
        <button class="ek-btn ek-btn-danger" data-action="delete-interaction" data-id="${i.id}" data-testid="delete-btn">Delete this mock</button>
        <div class="ek-row-inline-end ek-subtle">hash <span class="ek-tag">${i.hash}</span></div>
      </div>

      ${(i.method === 'WS' || i.method === 'SSE') ? `
      <div class="ek-section" data-testid="ws-frames-section">
        <div class="ek-section-head">
          <span>${i.method === 'WS' ? 'WebSocket Frames' : 'SSE Events'}</span>
          <div class="ek-row-inline-end">
            <label class="ek-switch ${i.wsLoop ? 'on' : ''}" title="Loop replay">
              <input type="checkbox" ${i.wsLoop ? 'checked' : ''} data-action="update-ws-loop" data-id="${i.id}"/>
              <span class="ek-switch-track"></span>
              <span class="ek-switch-label">Loop</span>
            </label>
          </div>
        </div>
        <div class="ek-section-body">
          ${(() => {
            try {
              const b = JSON.parse(i.responseBody || '{}');
              const frames = b.frames || [];
              if (!frames.length) return '<div class="ek-subtle">No frames recorded yet.</div>';
              return frames.slice(0, 30).map(f => `
                <div class="ek-ws-frame ek-ws-frame-${f.dir}">
                  <span class="ek-ws-dir">${f.dir === 'in' ? '▼ IN' : '▲ OUT'}</span>
                  <span class="ek-ws-t ek-subtle">+${f.t}ms</span>
                  <span class="ek-ws-data">${escapeHtml(String(f.data || '').slice(0, 120))}${String(f.data || '').length > 120 ? '…' : ''}</span>
                </div>
              `).join('') + (frames.length > 30 ? `<div class="ek-subtle">…${frames.length - 30} more frames</div>` : '');
            } catch { return '<div class="ek-subtle">Could not parse frame data.</div>'; }
          })()}
        </div>
      </div>` : ''}

      <div class="ek-section">
        <div class="ek-section-head"><span>Conditional Mock</span><span class="ek-subtle" style="font-size:10px">Fire N times then pass-through</span></div>
        <div class="ek-section-body">
          <div class="ek-field ek-row-inline" style="gap:8px;align-items:center">
            <div class="ek-label" style="min-width:60px">Max uses</div>
            <input class="ek-input" type="number" min="0" placeholder="∞ unlimited" style="max-width:120px"
              value="${i.mockMaxCount ?? ''}" data-action="update-max-count" data-id="${i.id}" data-testid="max-count-input"/>
            <span class="ek-subtle">${i.mockCallCount ? `${i.mockCallCount} hit${i.mockCallCount === 1 ? '' : 's'}` : ''}</span>
            ${i.mockCallCount ? `<button class="ek-btn ek-btn-ghost" data-action="reset-mock-count" data-id="${i.id}" style="font-size:10px">Reset</button>` : ''}
          </div>
        </div>
      </div>

      <div class="ek-section" data-testid="mock-chain-section">
        <div class="ek-section-head">
          <span>Mock Chain</span>
          <span class="ek-subtle" style="font-size:10px">Cycle through responses on each call</span>
          <div class="ek-row-inline-end">
            ${(i.mockChain && i.mockChain.length > 0) ? `
              <span class="ek-subtle" data-testid="mock-chain-cursor">step ${((i.mockChainCursor || 0) % i.mockChain.length) + 1}/${i.mockChain.length}</span>
              <label class="ek-row-inline" style="gap:4px;margin-left:8px">
                <input type="checkbox" ${i.mockChainLoop !== false ? 'checked' : ''} data-action="update-chain-loop" data-id="${i.id}" data-testid="chain-loop-toggle"/>
                <span class="ek-subtle">loop</span>
              </label>
              <button class="ek-btn ek-btn-ghost" data-action="reset-chain-cursor" data-id="${i.id}" style="font-size:10px;margin-left:6px" data-testid="chain-reset-btn">Reset cursor</button>
            ` : ''}
          </div>
        </div>
        <div class="ek-section-body">
          ${(i.mockChain && i.mockChain.length > 0) ? i.mockChain.map((step, sIdx) => {
            const active = (((i.mockChainCursor || 0) % i.mockChain.length) === sIdx);
            return `
              <div style="border:1px solid ${active ? 'var(--amber)' : 'var(--border)'};border-radius:6px;padding:6px;margin-bottom:6px" data-testid="chain-step-${sIdx}">
                <div class="ek-row-inline" style="gap:6px;margin-bottom:4px">
                  <span class="ek-subtle" style="min-width:60px">step ${sIdx + 1}${active ? ' • next' : ''}</span>
                  <input class="ek-input" type="number" value="${step.status || 200}" data-action="chain-status" data-id="${i.id}" data-step="${sIdx}" style="max-width:80px" data-testid="chain-status-${sIdx}" placeholder="status"/>
                  <button class="ek-kv-remove ek-row-inline-end" data-action="chain-remove" data-id="${i.id}" data-step="${sIdx}" data-testid="chain-remove-${sIdx}" aria-label="remove">×</button>
                </div>
                <textarea class="ek-textarea" style="min-height:50px;font-size:11px" data-action="chain-body" data-id="${i.id}" data-step="${sIdx}" data-testid="chain-body-${sIdx}" placeholder="response body (string or JSON)">${escapeHtml(typeof step.body === 'string' ? step.body : JSON.stringify(step.body || ''))}</textarea>
              </div>
            `;
          }).join('') : '<div class="ek-subtle">No chain steps. Add one to cycle responses on each call.</div>'}
          <button class="ek-btn ek-btn-ghost" data-action="chain-add" data-id="${i.id}" style="margin-top:4px" data-testid="chain-add-btn">＋ Add chain step</button>
        </div>
      </div>
    </div>
  `;
}

function renderFooter(count) {
  const recTag = state.tab.recording ? `<span class="ek-tag on">REC</span>` : `<span class="ek-tag">idle</span>`;
  const mockTag = state.tab.mocking ? `<span class="ek-tag amber">MOCK ON</span>` : '';
  const corsTag = state.settings.corsOverride ? `<span class="ek-tag amber" data-action="toggle-cors" data-testid="cors-chip" title="CORS override is ON — click to open settings">CORS</span>` : '';
  const scope = state.settings.scope || 'domain';
  const freeLimit = !state.isPro ? `<span class="ek-subtle ${state.allCount >= 50 ? 'ek-limit-warn' : ''}" title="Free tier: 50 recordings max. Upgrade for unlimited.">${state.allCount}/50</span>` : '';
  return `
    <div class="ek-footer">
      ${recTag} ${mockTag} ${corsTag}
      <span class="ek-subtle">${count} request${count === 1 ? '' : 's'}</span>
      <span class="ek-subtle">· scope: <span class="ek-tag" data-action="cycle-scope" data-testid="scope-chip" title="click to change scope">${scope}</span></span>
      ${freeLimit}
      <span class="ek-row-inline-end ek-subtle">${state.tab.host ? escapeHtml(state.tab.host) : `tab #${state.tabId ?? '—'}`}</span>
    </div>
  `;
}

// ---------- code-editor wiring (syntax highlighting overlay) ----------
function renderAllCodeEditors() {
  root.querySelectorAll('textarea[data-ce-id]').forEach(ta => {
    const id = ta.getAttribute('data-ce-id');
    const mirror = root.querySelector(`.ek-code-mirror[data-mirror-for="${id}"]`);
    if (!mirror) return;
    const sync = () => {
      mirror.innerHTML = highlightJSON(ta.value) + '\n'; // trailing NL so last line aligns
      mirror.scrollTop = ta.scrollTop;
      mirror.scrollLeft = ta.scrollLeft;
      const wrap = ta.closest('.ek-code-editor');
      if (wrap) wrap.classList.toggle('invalid', !!(ta.value.trim() && !isValidJSON(ta.value)));
    };
    sync();
    ta.addEventListener('input', sync);
    ta.addEventListener('scroll', () => { mirror.scrollTop = ta.scrollTop; mirror.scrollLeft = ta.scrollLeft; });
  });
}

// ---------- events ----------
function bindEvents() {
  root.querySelectorAll('[data-action]').forEach(el => {
    const action = el.getAttribute('data-action');
    const id = el.getAttribute('data-id');

    if (action === 'select') el.addEventListener('click', (e) => {
      if (e.target.closest('[data-action="toggle-mock"]')) return;
      state.selectedId = el.getAttribute('data-id');
      state.detailOpen = true; render();
    });
    else if (action === 'start-recording') el.addEventListener('click', onStartRecording);
    else if (action === 'stop-recording') el.addEventListener('click', onStopRecording);
    else if (action === 'toggle-mocking') el.addEventListener('change', onToggleMocking);
    else if (action === 'toggle-cors-master') el.addEventListener('change', async (e) => {
      await BG({ type: 'echokit:settings:update', patch: { corsOverride: e.target.checked } });
      await refresh(); render();
    });
    else if (action === 'toggle-waterfall') el.addEventListener('click', () => {
      state.waterfall = !state.waterfall; render();
    });
    else if (action === 'toggle-block') el.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!state.isPro) { showProGate('API Blocking'); return; }
      const tid = el.getAttribute('data-id');
      const current = state.interactions.find(x => x.id === tid);
      if (!current) return;
      await BG({ type: 'echokit:interaction:update', id: tid, patch: { blocked: !current.blocked } });
      await refresh(); render();
    });
    else if (action === 'toggle-menu') el.addEventListener('click', async (e) => { e.stopPropagation(); state.menuOpen = !state.menuOpen; if (state.menuOpen) await tryReadClipboardPreview(); renderMenu(); });
    else if (action === 'toggle-cors') el.addEventListener('click', () => { state.menuOpen = false; showSettingsDialog(); });
    else if (action === 'cycle-scope') el.addEventListener('click', async () => {
      const order = ['domain', 'tab', 'global'];
      const next = order[(order.indexOf(state.settings.scope || 'domain') + 1) % order.length];
      await BG({ type: 'echokit:settings:update', patch: { scope: next } });
      await refresh(); render();
    });
    else if (action === 'search') {
      // Soft update: do not full-render on every keystroke. Update state + only
      // re-render the list/footer so the search input itself is untouched.
      let t;
      el.addEventListener('input', (e) => {
        state.search = e.target.value;
        clearTimeout(t);
        t = setTimeout(() => softRenderList(), 80);
      });
    }
    else if (action === 'filter-method') el.addEventListener('click', () => {
      const m = el.getAttribute('data-method');
      state.methodFilter = state.methodFilter === m ? null : m;
      render();
    });
    else if (action === 'filter-status') el.addEventListener('change', (e) => { state.statusFilter = e.target.value || null; render(); });
    else if (action === 'toggle-mock') {
      const handler = async () => {
        const current = state.interactions.find(x => x.id === id);
        if (!current) return;
        await BG({ type: 'echokit:interaction:update', id, patch: { mockEnabled: !current.mockEnabled } });
        await refresh(); render();
      };
      if (el.tagName === 'INPUT') el.addEventListener('change', handler);
      else el.addEventListener('click', (e) => { e.stopPropagation(); handler(); });
    }
    else if (action === 'update-latency' || action === 'update-latency-input') el.addEventListener('change', async (e) => {
      await BG({ type: 'echokit:interaction:update', id, patch: { mockLatency: Number(e.target.value) || 0 } });
      await refresh(); render();
    });
    else if (action === 'update-error-mode') el.addEventListener('change', async (e) => {
      await BG({ type: 'echokit:interaction:update', id, patch: { mockErrorMode: e.target.value } });
      await refresh(); render();
    });
    else if (action === 'update-match-mode') el.addEventListener('change', async (e) => {
      if (e.target.value !== 'strict' && !state.isPro) { showProGate('Advanced Match Modes'); e.target.value = 'strict'; return; }
      await BG({ type: 'echokit:interaction:update', id, patch: { matchMode: e.target.value } });
      await refresh(); render();
    });
    else if (action === 'update-status') el.addEventListener('change', async (e) => {
      await BG({ type: 'echokit:interaction:update', id, patch: { overrideStatus: Number(e.target.value) || 200 } });
      await refresh(); render();
    });
    else if (action === 'update-body') {
      let t;
      el.addEventListener('input', (e) => {
        const v = e.target.value;
        const saveStatus = root.querySelector('[data-testid="body-save-status"]');
        if (saveStatus) saveStatus.textContent = 'saving…';
        clearTimeout(t);
        t = setTimeout(async () => {
          await BG({ type: 'echokit:interaction:update', id, patch: { overrideBody: v } });
          await refresh();
          if (saveStatus) saveStatus.textContent = 'saved';
        }, 400);
      });
    }
    else if (action === 'format-json') el.addEventListener('click', async () => {
      const ta = root.querySelector('textarea[data-action="update-body"]');
      if (!ta) return;
      try {
        const p = JSON.parse(ta.value);
        const pretty = JSON.stringify(p, null, 2);
        ta.value = pretty;
        await BG({ type: 'echokit:interaction:update', id, patch: { overrideBody: pretty } });
        await refresh(); render();
      } catch {}
    });
    else if (action === 'reset-body') el.addEventListener('click', async () => {
      await BG({ type: 'echokit:interaction:update', id, patch: { overrideBody: null } });
      await refresh(); render();
    });
    else if (action === 'update-max-count') el.addEventListener('change', async (e) => {
      const v = e.target.value.trim();
      await BG({ type: 'echokit:interaction:update', id, patch: { mockMaxCount: v === '' ? null : (Number(v) || 0) } });
      await refresh(); render();
    });
    else if (action === 'update-ws-loop') el.addEventListener('change', async (e) => {
      await BG({ type: 'echokit:interaction:update', id, patch: { wsLoop: e.target.checked } });
      await refresh(); render();
    });
    else if (action === 'reset-mock-count') el.addEventListener('click', async () => {
      await BG({ type: 'echokit:interaction:update', id, patch: { mockCallCount: 0 } });
      await refresh(); render();
    });
    else if (action === 'chain-add') el.addEventListener('click', async () => {
      const curr = state.interactions.find(x => x.id === id);
      const chain = [...(curr?.mockChain || []), { status: 200, body: '', headers: {} }];
      await BG({ type: 'echokit:interaction:update', id, patch: { mockChain: chain } });
      await refresh(); render();
    });
    else if (action === 'chain-remove') el.addEventListener('click', async () => {
      const sIdx = Number(el.getAttribute('data-step'));
      const curr = state.interactions.find(x => x.id === id);
      const chain = [...(curr?.mockChain || [])];
      chain.splice(sIdx, 1);
      const cursor = chain.length ? Math.min(curr.mockChainCursor || 0, chain.length - 1) : 0;
      await BG({ type: 'echokit:interaction:update', id, patch: { mockChain: chain.length ? chain : null, mockChainCursor: cursor } });
      await refresh(); render();
    });
    else if (action === 'chain-status') el.addEventListener('change', async (e) => {
      const sIdx = Number(el.getAttribute('data-step'));
      const curr = state.interactions.find(x => x.id === id);
      const chain = [...(curr?.mockChain || [])];
      chain[sIdx] = { ...(chain[sIdx] || {}), status: Number(e.target.value) || 200 };
      await BG({ type: 'echokit:interaction:update', id, patch: { mockChain: chain } });
      await refresh();
    });
    else if (action === 'chain-body') el.addEventListener('change', async (e) => {
      const sIdx = Number(el.getAttribute('data-step'));
      const curr = state.interactions.find(x => x.id === id);
      const chain = [...(curr?.mockChain || [])];
      chain[sIdx] = { ...(chain[sIdx] || {}), body: e.target.value };
      await BG({ type: 'echokit:interaction:update', id, patch: { mockChain: chain } });
      await refresh();
    });
    else if (action === 'update-chain-loop') el.addEventListener('change', async (e) => {
      await BG({ type: 'echokit:interaction:update', id, patch: { mockChainLoop: e.target.checked } });
      await refresh(); render();
    });
    else if (action === 'reset-chain-cursor') el.addEventListener('click', async () => {
      await BG({ type: 'echokit:interaction:update', id, patch: { mockChainCursor: 0 } });
      await refresh(); render();
    });
    else if (action === 'header-add') el.addEventListener('click', async () => {
      const curr = state.interactions.find(x => x.id === id);
      const headers = { ...(curr.overrideHeaders || curr.responseHeaders || {}) };
      let k = 'x-custom-header', i2 = 1;
      while (headers[k]) k = `x-custom-header-${i2++}`;
      headers[k] = '';
      await BG({ type: 'echokit:interaction:update', id, patch: { overrideHeaders: headers } });
      await refresh(); render();
    });
    else if (action === 'header-remove') el.addEventListener('click', async () => {
      const key = el.getAttribute('data-key');
      const curr = state.interactions.find(x => x.id === id);
      const headers = { ...(curr.overrideHeaders || curr.responseHeaders || {}) };
      delete headers[key];
      await BG({ type: 'echokit:interaction:update', id, patch: { overrideHeaders: headers } });
      await refresh(); render();
    });
    else if (action === 'header-key') el.addEventListener('change', async (e) => {
      const orig = el.getAttribute('data-orig');
      const next = e.target.value.trim();
      if (!next || next === orig) return;
      const curr = state.interactions.find(x => x.id === id);
      const headers = { ...(curr.overrideHeaders || curr.responseHeaders || {}) };
      headers[next] = headers[orig]; delete headers[orig];
      await BG({ type: 'echokit:interaction:update', id, patch: { overrideHeaders: headers } });
      await refresh(); render();
    });
    else if (action === 'header-val') el.addEventListener('change', async (e) => {
      const key = el.getAttribute('data-key');
      const curr = state.interactions.find(x => x.id === id);
      const headers = { ...(curr.overrideHeaders || curr.responseHeaders || {}) };
      headers[key] = e.target.value;
      await BG({ type: 'echokit:interaction:update', id, patch: { overrideHeaders: headers } });
      await refresh();
    });
    else if (action === 'delete-interaction') el.addEventListener('click', async () => {
      if (!confirm('Delete this recorded API? This cannot be undone.')) return;
      await BG({ type: 'echokit:interaction:delete', id });
      state.selectedId = null; state.detailOpen = false;
      await refresh(); render();
    });
    else if (action === 'set-active-version') el.addEventListener('change', async (e) => {
      await BG({ type: 'echokit:interaction:setActiveVersion', id: e.target.value });
      await refresh(); render();
    });
    else if (action === 'close-detail') el.addEventListener('click', () => { state.detailOpen = false; state.selectedId = null; render(); });
    else if (action === 'resize') bindResizer(el);
  });
}

function bindResizer(el) {
  let startX = 0, startW = state.listWidth;
  const onMove = (ev) => {
    const dx = ev.clientX - startX;
    state.listWidth = Math.max(260, Math.min(window.innerWidth * 0.6, startW + dx));
    const app = root.querySelector('.ek-app');
    if (app) app.style.setProperty('--list-width', `${state.listWidth}px`);
  };
  const onUp = () => {
    el.classList.remove('dragging');
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onUp);
  };
  el.addEventListener('mousedown', (ev) => {
    startX = ev.clientX; startW = state.listWidth;
    el.classList.add('dragging');
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    ev.preventDefault();
  });
}

// Update just the list + footer without touching the toolbar/search (avoids cursor reset)
function softRenderList() {
  const list = root.querySelector('[data-testid="api-list"]');
  if (!list) return render();
  const items = filteredInteractions();
  const grouped = groupByDomain(items);
  const scrollTop = list.scrollTop;
  list.innerHTML = items.length === 0 ? renderEmpty() : grouped.map(renderDomainGroup).join('');
  list.scrollTop = scrollTop;
  // rebind list-level events
  list.querySelectorAll('[data-action="select"]').forEach(el => el.addEventListener('click', (e) => {
    if (e.target.closest('[data-action="toggle-mock"]')) return;
    state.selectedId = el.getAttribute('data-id'); state.detailOpen = true; render();
  }));
  list.querySelectorAll('[data-action="toggle-mock"]').forEach(el => {
    el.addEventListener('click', async (e) => {
      e.stopPropagation();
      const tid = el.getAttribute('data-id');
      const current = state.interactions.find(x => x.id === tid);
      if (!current) return;
      await BG({ type: 'echokit:interaction:update', id: tid, patch: { mockEnabled: !current.mockEnabled } });
      await refresh(); render();
    });
  });
  // Update footer count
  const footer = root.querySelector('.ek-footer');
  if (footer) footer.outerHTML = renderFooter(items.length);
}

// ---------- actions ----------
async function onStartRecording() {
  if (state.tabId == null) return;
  await BG({ type: 'echokit:recording:start', tabId: state.tabId });
  await refresh(); render();
}
async function onStopRecording() {
  await BG({ type: 'echokit:recording:stop', tabId: state.tabId });
  await refresh(); render();
}
async function onToggleMocking(e) {
  await BG({ type: 'echokit:mocking:toggle', tabId: state.tabId, enabled: e.target.checked });
  await refresh(); render();
}
async function onClearSession() {
  if (!confirm(`Clear ${state.interactions.length} recordings visible in the current scope (${state.settings.scope})?`)) return;
  await BG({ type: 'echokit:clear:scoped', tabId: state.tabId });
  state.selectedId = null; state.detailOpen = false;
  await refresh(); render();
}
async function onExport() {
  const res = await BG({ type: 'echokit:export' });
  const blob = new Blob([JSON.stringify(res.data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `echokit-export-${Date.now()}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}
function showImportDialog() {
  const overlay = document.createElement('div');
  overlay.className = 'ek-modal-overlay';
  overlay.innerHTML = `
    <div class="ek-modal" data-testid="import-modal">
      <div class="ek-modal-title">Import mocks</div>
      <div class="ek-subtle">Paste an EchoKit export JSON, or choose a file.</div>
      <textarea class="ek-textarea" style="min-height:120px" placeholder='{"version":2,"interactions":[…]}'></textarea>
      <input type="file" accept="application/json,.json" data-testid="import-file"/>
      <label class="ek-row-inline" style="gap:6px">
        <input type="radio" name="ek-strategy" value="merge" checked/> <span>Merge (replace by id)</span>
      </label>
      <label class="ek-row-inline" style="gap:6px">
        <input type="radio" name="ek-strategy" value="override"/> <span>Override (wipe existing)</span>
      </label>
      <div class="ek-modal-actions">
        <button class="ek-btn ek-btn-ghost" data-a="cancel">Cancel</button>
        <button class="ek-btn ek-btn-primary" data-a="confirm" data-testid="import-confirm">Import</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  const fileInput = overlay.querySelector('input[type="file"]');
  const ta = overlay.querySelector('textarea');
  fileInput.addEventListener('change', async () => { const f = fileInput.files?.[0]; if (f) ta.value = await f.text(); });
  overlay.querySelector('[data-a="cancel"]').addEventListener('click', () => overlay.remove());
  overlay.querySelector('[data-a="confirm"]').addEventListener('click', async () => {
    try {
      const data = JSON.parse(ta.value);
      const strategy = overlay.querySelector('input[name="ek-strategy"]:checked').value;
      const r = await BG({ type: 'echokit:import', data, strategy });
      overlay.remove();
      if (r?.ok) { await refresh(); render(); } else alert('Import failed: ' + (r?.error || 'unknown'));
    } catch (e) { alert('Invalid JSON: ' + e.message); }
  });
}

function showSettingsDialog() {
  const s = state.settings;
  const overlay = document.createElement('div');
  overlay.className = 'ek-modal-overlay';
  overlay.innerHTML = `
    <div class="ek-modal" data-testid="settings-modal">
      <div class="ek-modal-title">Settings</div>

      <div class="ek-settings-row">
        <div>
          <div class="ek-settings-title">Scope</div>
          <div class="ek-settings-hint">Which recordings are visible + which mocks can fire on the current tab.</div>
        </div>
        <select class="ek-select" data-a="scope" data-testid="settings-scope" style="max-width:160px">
          <option value="domain" ${s.scope==='domain'?'selected':''}>Domain (default)</option>
          <option value="tab" ${s.scope==='tab'?'selected':''}>Tab (strict)</option>
          <option value="global" ${s.scope==='global'?'selected':''}>Global</option>
        </select>
      </div>

      <div class="ek-settings-row">
        <div>
          <div class="ek-settings-title">Theme</div>
          <div class="ek-settings-hint">UI appearance for popup + DevTools panel.</div>
        </div>
        <select class="ek-select" data-a="theme" data-testid="settings-theme" style="max-width:160px">
          <option value="dark" ${s.theme==='dark'?'selected':''}>Dark</option>
          <option value="light" ${s.theme==='light'?'selected':''}>Light</option>
          <option value="auto" ${s.theme==='auto'?'selected':''}>Auto (follow OS)</option>
        </select>
      </div>

      <div class="ek-settings-row">
        <div>
          <div class="ek-settings-title">CORS Override</div>
          <div class="ek-settings-hint">Inject <span class="ek-tag">Access-Control-Allow-*</span> headers into real responses.</div>
        </div>
        <label class="ek-switch ${s.corsOverride?'on':''}">
          <input type="checkbox" ${s.corsOverride?'checked':''} data-a="cors" data-testid="cors-toggle"/>
          <span class="ek-switch-track"></span>
          <span class="ek-switch-label">${s.corsOverride?'ON':'OFF'}</span>
        </label>
      </div>

      <div class="ek-settings-row">
        <div>
          <div class="ek-settings-title">Auto-open popup on refresh</div>
          <div class="ek-settings-hint">When a tab reloads while recording, pop this panel back open.</div>
        </div>
        <label class="ek-switch ${s.autoOpenOnRefresh?'on':''}">
          <input type="checkbox" ${s.autoOpenOnRefresh?'checked':''} data-a="auto-open" data-testid="auto-open-toggle"/>
          <span class="ek-switch-track"></span>
          <span class="ek-switch-label">${s.autoOpenOnRefresh?'ON':'OFF'}</span>
        </label>
      </div>

      <div class="ek-settings-row">
        <div style="flex:1">
          <div class="ek-settings-title">URL Blocklist</div>
          <div class="ek-settings-hint">Block any network request whose URL matches. Uses Chrome's <span class="ek-tag">urlFilter</span> syntax (substring or <span class="ek-tag">||domain.com</span> / <span class="ek-tag">^</span> / <span class="ek-tag">*</span>).</div>
          <div id="ek-blocklist" style="margin-top:8px" data-testid="blocklist">
            ${(s.blocklist || []).map((b, idx) => `
              <div class="ek-kv-row">
                <input class="ek-input" value="${escapeHtml(b.pattern)}" data-a="bl-pattern" data-idx="${idx}" placeholder="e.g. ||tracking.example.com^"/>
                <label class="ek-row-inline" style="gap:6px"><input type="checkbox" ${b.enabled?'checked':''} data-a="bl-toggle" data-idx="${idx}"/> <span class="ek-subtle">${b.enabled ? 'ON' : 'off'}</span></label>
                <button class="ek-kv-remove" data-a="bl-remove" data-idx="${idx}" aria-label="remove">×</button>
              </div>
            `).join('')}
          </div>
          <button class="ek-btn ek-btn-ghost" data-a="bl-add" style="margin-top:6px" data-testid="blocklist-add">＋ Add blocklist pattern</button>
        </div>
      </div>

      <div class="ek-settings-row">
        <div style="flex:1">
          <div class="ek-settings-title">URL Rewrite Rules</div>
          <div class="ek-settings-hint">Rewrite outgoing URLs before they hit the network. <span class="ek-tag">From</span> can be a substring or a JS regex like <span class="ek-tag">/api\\/v1/g</span>.</div>
          <div id="ek-rewritelist" style="margin-top:8px" data-testid="rewritelist">
            ${(s.rewriteRules || []).map((r, idx) => `
              <div class="ek-kv-row" data-testid="rewrite-row">
                <input class="ek-input" value="${escapeHtml(r.from || '')}" data-a="rw-from" data-idx="${idx}" placeholder="from (substring or /regex/flags)" data-testid="rewrite-from-${idx}"/>
                <input class="ek-input" value="${escapeHtml(r.to || '')}" data-a="rw-to" data-idx="${idx}" placeholder="to (replacement)" data-testid="rewrite-to-${idx}"/>
                <div style="display:flex;gap:6px;align-items:center">
                  <label class="ek-row-inline" style="gap:4px"><input type="checkbox" ${r.enabled?'checked':''} data-a="rw-toggle" data-idx="${idx}" data-testid="rewrite-toggle-${idx}"/><span class="ek-subtle">${r.enabled?'ON':'off'}</span></label>
                  <button class="ek-kv-remove" data-a="rw-remove" data-idx="${idx}" data-testid="rewrite-remove-${idx}" aria-label="remove">×</button>
                </div>
              </div>
            `).join('')}
          </div>
          <button class="ek-btn ek-btn-ghost" data-a="rw-add" style="margin-top:6px" data-testid="rewrite-add">＋ Add rewrite rule</button>
        </div>
      </div>

      <div class="ek-settings-row">
        <div style="flex:1">
          <div class="ek-settings-title">Response Transform Rules</div>
          <div class="ek-settings-hint">Mutate mocked responses on the fly: add/remove headers, replace body, or run a regex over the body.</div>
          <div id="ek-transformlist" style="margin-top:8px" data-testid="transformlist">
            ${(s.transformRules || []).map((r, idx) => `
              <div style="border:1px solid var(--border);border-radius:6px;padding:8px;margin-bottom:6px" data-testid="transform-row">
                <div class="ek-row-inline" style="gap:6px;margin-bottom:6px">
                  <input class="ek-input" value="${escapeHtml(r.urlPattern || '')}" data-a="tr-url" data-idx="${idx}" placeholder="url contains… (blank = all)" style="flex:1" data-testid="transform-url-${idx}"/>
                  <select class="ek-select" data-a="tr-action" data-idx="${idx}" style="max-width:160px" data-testid="transform-action-${idx}">
                    <option value="add-header" ${r.action==='add-header'?'selected':''}>add header</option>
                    <option value="remove-header" ${r.action==='remove-header'?'selected':''}>remove header</option>
                    <option value="set-body" ${r.action==='set-body'?'selected':''}>set body</option>
                    <option value="regex-replace-body" ${r.action==='regex-replace-body'?'selected':''}>regex replace body</option>
                  </select>
                  <label class="ek-row-inline" style="gap:4px"><input type="checkbox" ${r.enabled?'checked':''} data-a="tr-toggle" data-idx="${idx}" data-testid="transform-toggle-${idx}"/><span class="ek-subtle">${r.enabled?'ON':'off'}</span></label>
                  <button class="ek-kv-remove" data-a="tr-remove" data-idx="${idx}" data-testid="transform-remove-${idx}" aria-label="remove">×</button>
                </div>
                <div class="ek-row-inline" style="gap:6px">
                  <input class="ek-input" value="${escapeHtml(r.key || '')}" data-a="tr-key" data-idx="${idx}" placeholder="${r.action === 'set-body' ? '(unused)' : (r.action === 'regex-replace-body' ? 'regex pattern' : 'header name')}" style="flex:1" data-testid="transform-key-${idx}"/>
                  <input class="ek-input" value="${escapeHtml(r.value || '')}" data-a="tr-value" data-idx="${idx}" placeholder="${r.action === 'remove-header' ? '(unused)' : (r.action === 'set-body' ? 'new body (string/JSON)' : (r.action === 'regex-replace-body' ? 'replacement' : 'header value'))}" style="flex:2" data-testid="transform-value-${idx}"/>
                </div>
              </div>
            `).join('')}
          </div>
          <button class="ek-btn ek-btn-ghost" data-a="tr-add" style="margin-top:6px" data-testid="transform-add">＋ Add transform rule</button>
        </div>
      </div>

      <div class="ek-settings-row">
        <div>
          <div class="ek-settings-title">Wipe ALL recordings</div>
          <div class="ek-settings-hint">Delete every recorded interaction across every scope, tab, and domain.</div>
        </div>
        <button class="ek-btn ek-btn-danger" data-a="clear-all" data-testid="clear-all-btn">Wipe</button>
      </div>

      <div class="ek-settings-row">
        <div style="flex:1">
          <div class="ek-settings-title">License Key ${state.isPro ? '<span class="ek-pro-badge" style="font-size:9px;padding:2px 6px">PRO ACTIVE</span>' : ''}</div>
          <div class="ek-settings-hint">Enter your EchoKit Pro key to unlock all features. Keys start with <span class="ek-tag">EK-PRO-</span>, <span class="ek-tag">EK-YEAR-</span>, or <span class="ek-tag">EK-LTD-</span>.</div>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px;min-width:200px">
          <input class="ek-input" type="text" id="ek-license-input" placeholder="EK-PRO-…" style="font-family:var(--font-mono);font-size:11px" data-testid="license-key-input"/>
          <button class="ek-btn ek-btn-primary" data-a="license-activate" data-testid="license-activate-btn">Activate</button>
          ${!state.isPro ? `<a href="#" data-a="get-pro" style="font-size:11px;color:var(--amber);text-decoration:none;text-align:center">Get Pro →</a>` : `<button class="ek-btn ek-btn-ghost" data-a="license-remove" style="font-size:10px">Remove license</button>`}
        </div>
      </div>

      <div class="ek-modal-actions">
        <button class="ek-btn ek-btn-primary" data-a="close">Done</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  overlay.querySelector('[data-a="close"]').addEventListener('click', () => overlay.remove());
  overlay.querySelector('[data-a="scope"]').addEventListener('change', async (e) => {
    await BG({ type: 'echokit:settings:update', patch: { scope: e.target.value } });
    await refresh(); render();
  });
  overlay.querySelector('[data-a="theme"]').addEventListener('change', async (e) => {
    await BG({ type: 'echokit:settings:update', patch: { theme: e.target.value } });
    await refresh(); applyTheme(); render();
  });
  overlay.querySelector('[data-a="cors"]').addEventListener('change', async (e) => {
    await BG({ type: 'echokit:settings:update', patch: { corsOverride: e.target.checked } });
    await refresh(); overlay.remove(); render(); showSettingsDialog();
  });
  overlay.querySelector('[data-a="auto-open"]').addEventListener('change', async (e) => {
    await BG({ type: 'echokit:settings:update', patch: { autoOpenOnRefresh: e.target.checked } });
    await refresh(); overlay.remove(); render(); showSettingsDialog();
  });
  overlay.querySelector('[data-a="clear-all"]').addEventListener('click', async () => {
    if (!confirm('Delete ALL recordings, every scope, every tab, every domain. Cannot be undone.')) return;
    await BG({ type: 'echokit:interactions:clearAll' });
    overlay.remove();
    state.selectedId = null; state.detailOpen = false;
    await refresh(); render();
  });

  // --- Blocklist handlers ---
  const reopen = () => { overlay.remove(); showSettingsDialog(); };
  overlay.querySelectorAll('[data-a="bl-pattern"]').forEach(el => el.addEventListener('change', async (e) => {
    const idx = Number(el.getAttribute('data-idx'));
    const bl = [...(state.settings.blocklist || [])];
    bl[idx] = { ...(bl[idx] || {}), pattern: e.target.value };
    await BG({ type: 'echokit:settings:update', patch: { blocklist: bl } });
    await refresh();
  }));
  overlay.querySelectorAll('[data-a="bl-toggle"]').forEach(el => el.addEventListener('change', async (e) => {
    const idx = Number(el.getAttribute('data-idx'));
    const bl = [...(state.settings.blocklist || [])];
    bl[idx] = { ...(bl[idx] || {}), enabled: e.target.checked };
    await BG({ type: 'echokit:settings:update', patch: { blocklist: bl } });
    await refresh(); reopen();
  }));
  overlay.querySelectorAll('[data-a="bl-remove"]').forEach(el => el.addEventListener('click', async () => {
    const idx = Number(el.getAttribute('data-idx'));
    const bl = [...(state.settings.blocklist || [])];
    bl.splice(idx, 1);
    await BG({ type: 'echokit:settings:update', patch: { blocklist: bl } });
    await refresh(); reopen();
  }));
  overlay.querySelector('[data-a="bl-add"]')?.addEventListener('click', async () => {
    const bl = [...(state.settings.blocklist || []), { pattern: '', enabled: true }];
    await BG({ type: 'echokit:settings:update', patch: { blocklist: bl } });
    await refresh(); reopen();
  });

  // --- Rewrite rules handlers ---
  overlay.querySelectorAll('[data-a="rw-from"]').forEach(el => el.addEventListener('change', async (e) => {
    const idx = Number(el.getAttribute('data-idx'));
    const rules = [...(state.settings.rewriteRules || [])];
    rules[idx] = { ...(rules[idx] || {}), from: e.target.value };
    await BG({ type: 'echokit:settings:update', patch: { rewriteRules: rules } });
    await refresh();
  }));
  overlay.querySelectorAll('[data-a="rw-to"]').forEach(el => el.addEventListener('change', async (e) => {
    const idx = Number(el.getAttribute('data-idx'));
    const rules = [...(state.settings.rewriteRules || [])];
    rules[idx] = { ...(rules[idx] || {}), to: e.target.value };
    await BG({ type: 'echokit:settings:update', patch: { rewriteRules: rules } });
    await refresh();
  }));
  overlay.querySelectorAll('[data-a="rw-toggle"]').forEach(el => el.addEventListener('change', async (e) => {
    const idx = Number(el.getAttribute('data-idx'));
    const rules = [...(state.settings.rewriteRules || [])];
    rules[idx] = { ...(rules[idx] || {}), enabled: e.target.checked };
    await BG({ type: 'echokit:settings:update', patch: { rewriteRules: rules } });
    await refresh(); reopen();
  }));
  overlay.querySelectorAll('[data-a="rw-remove"]').forEach(el => el.addEventListener('click', async () => {
    const idx = Number(el.getAttribute('data-idx'));
    const rules = [...(state.settings.rewriteRules || [])];
    rules.splice(idx, 1);
    await BG({ type: 'echokit:settings:update', patch: { rewriteRules: rules } });
    await refresh(); reopen();
  }));
  overlay.querySelector('[data-a="rw-add"]')?.addEventListener('click', async () => {
    const rules = [...(state.settings.rewriteRules || []), { from: '', to: '', enabled: true }];
    await BG({ type: 'echokit:settings:update', patch: { rewriteRules: rules } });
    await refresh(); reopen();
  });

  // --- Transform rules handlers ---
  const trUpdate = async (idx, patch) => {
    const rules = [...(state.settings.transformRules || [])];
    rules[idx] = { phase: 'response', ...(rules[idx] || {}), ...patch };
    await BG({ type: 'echokit:settings:update', patch: { transformRules: rules } });
    await refresh();
  };
  overlay.querySelectorAll('[data-a="tr-url"]').forEach(el => el.addEventListener('change', (e) => trUpdate(Number(el.getAttribute('data-idx')), { urlPattern: e.target.value })));
  overlay.querySelectorAll('[data-a="tr-key"]').forEach(el => el.addEventListener('change', (e) => trUpdate(Number(el.getAttribute('data-idx')), { key: e.target.value })));
  overlay.querySelectorAll('[data-a="tr-value"]').forEach(el => el.addEventListener('change', (e) => trUpdate(Number(el.getAttribute('data-idx')), { value: e.target.value })));
  overlay.querySelectorAll('[data-a="tr-action"]').forEach(el => el.addEventListener('change', async (e) => {
    await trUpdate(Number(el.getAttribute('data-idx')), { action: e.target.value });
    reopen();
  }));
  overlay.querySelectorAll('[data-a="tr-toggle"]').forEach(el => el.addEventListener('change', async (e) => {
    await trUpdate(Number(el.getAttribute('data-idx')), { enabled: e.target.checked });
    reopen();
  }));
  overlay.querySelectorAll('[data-a="tr-remove"]').forEach(el => el.addEventListener('click', async () => {
    const idx = Number(el.getAttribute('data-idx'));
    const rules = [...(state.settings.transformRules || [])];
    rules.splice(idx, 1);
    await BG({ type: 'echokit:settings:update', patch: { transformRules: rules } });
    await refresh(); reopen();
  }));
  overlay.querySelector('[data-a="tr-add"]')?.addEventListener('click', async () => {
    const rules = [...(state.settings.transformRules || []), { phase: 'response', urlPattern: '', action: 'add-header', key: '', value: '', enabled: true }];
    await BG({ type: 'echokit:settings:update', patch: { transformRules: rules } });
    await refresh(); reopen();
  });
  // Pre-fill license key input
  BG({ type: 'echokit:license:check' }).then(res => {
    const input = overlay.querySelector('#ek-license-input');
    if (input && res?.key) input.value = res.key;
  });
  // License activation
  overlay.querySelector('[data-a="license-activate"]')?.addEventListener('click', async () => {
    const keyInput = overlay.querySelector('#ek-license-input');
    const key = keyInput?.value?.trim() || '';
    if (!key) { toast('Enter a license key first'); return; }
    const res = await BG({ type: 'echokit:license:set', key });
    if (res?.ok && res.pro) { toast('Pro license activated!'); state.isPro = true; await refresh(); render(); overlay.remove(); showSettingsDialog(); }
    else toast('Invalid key: ' + (res?.error || 'format not recognized'), 4000);
  });
  overlay.querySelector('[data-a="license-remove"]')?.addEventListener('click', async () => {
    if (!confirm('Remove your Pro license from this device?')) return;
    await BG({ type: 'echokit:license:set', key: '' });
    state.isPro = false; await refresh(); render(); overlay.remove(); showSettingsDialog();
  });
  overlay.querySelector('[data-a="get-pro"]')?.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: 'https://echokit.dev/pricing' }).catch(() => window.open('https://echokit.dev/pricing', '_blank'));
  });
}

function showShortcutsDialog() {
  const overlay = document.createElement('div');
  overlay.className = 'ek-modal-overlay';
  overlay.innerHTML = `
    <div class="ek-modal" data-testid="shortcuts-modal">
      <div class="ek-modal-title">Keyboard shortcuts</div>
      <div class="ek-settings-row"><div class="ek-settings-title">Toggle recording</div><span class="ek-kbd">Alt+Shift+R</span></div>
      <div class="ek-settings-row"><div class="ek-settings-title">Toggle mock mode</div><span class="ek-kbd">Alt+Shift+M</span></div>
      <div class="ek-settings-row"><div class="ek-settings-title">Open popup</div><span class="ek-kbd">Alt+Shift+E</span></div>
      <div class="ek-subtle">Customize these at <span class="ek-tag">chrome://extensions/shortcuts</span>.</div>
      <div class="ek-modal-actions"><button class="ek-btn ek-btn-primary" data-a="close">Done</button></div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  overlay.querySelector('[data-a="close"]').addEventListener('click', () => overlay.remove());
}

// ---------- filters & helpers ----------
function filteredInteractions() {
  const q = state.search.trim().toLowerCase();
  return state.interactions.filter(i => {
    if (state.methodFilter && (i.method || '').toUpperCase() !== state.methodFilter) return false;
    if (state.statusFilter != null) {
      const bucket = String(Math.floor((i.responseStatus || 0) / 100));
      if (state.statusFilter === '0') { if ((i.responseStatus || 0) !== 0) return false; }
      else if (bucket !== state.statusFilter) return false;
    }
    if (q && !i.url.toLowerCase().includes(q)) return false;
    return true;
  }).sort((a, b) => b.timestamp - a.timestamp);
}
function groupByDomain(list) {
  const map = new Map();
  for (const i of list) {
    const d = domainOf(i.url);
    if (!map.has(d)) map.set(d, []);
    map.get(d).push(i);
  }
  return [...map.entries()].map(([domain, items]) => ({ domain, items }));
}
function domainOf(url) { try { return new URL(url, location.href).host || '(local)'; } catch { return '(unknown)'; } }
function prettyUrl(url) {
  try { const u = new URL(url, location.href); return { path: u.pathname, query: u.search }; }
  catch { return { path: url, query: '' }; }
}
function escapeHtml(s) {
  if (s == null) return '';
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
